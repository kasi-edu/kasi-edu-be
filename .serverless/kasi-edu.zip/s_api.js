
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pisanggoreng',
  applicationName: 'kasi-edu',
  appUid: 'jzl0Wg5n6VnBZhJwtY',
  orgUid: 'z4dR7PspSYDTqdnd5B',
  deploymentUid: '09c23995-062e-4055-9672-d02402b20670',
  serviceName: 'kasi-edu',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'kasi-edu-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/src/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}