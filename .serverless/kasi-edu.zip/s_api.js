
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pisanggoreng',
  applicationName: 'kasi-edu',
  appUid: 'jzl0Wg5n6VnBZhJwtY',
  orgUid: 'z4dR7PspSYDTqdnd5B',
  deploymentUid: 'eee8932e-71bf-4342-bf55-a752bcd0e068',
  serviceName: 'kasi-edu',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'kasi-edu-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/src/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}